declare module '*.css' { 
    const Content: string;
    export default Content;
}

declare module '*.html' {
    const Content: string;
    export default Content;
}

declare module '*.txt' {
    const Content: string;
    export default Content;
}

declare module '*.json' {
    const Content: string;
    export default Content;
}

declare module '*.jsworker' {
    const Content: string;
    export default Content;
}

declare module '*.png' {
    const Content: string;
    export default Content;
}

declare module '*.jpg' {
    const Content: string;
    export default Content;
}

declare module '*.jpeg' {
    const Content: string;
    export default Content;
}

declare module '*.gif' {
    const Content: string;
    export default Content;
}

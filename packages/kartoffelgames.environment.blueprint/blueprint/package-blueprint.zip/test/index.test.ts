import { describe, it } from '@std/testing/bdd';
import { expect } from '@std/expect';

describe("Main", () => {
    it("Placeholder Test", () => {
        const lResult = 2 + 3;
        expect(lResult).toBe(5);
    });
});